// Массив с изображениями

const images = [
    "image1.jpg",
    "image2.jpg",
    "image3.jpg",
    "image4.jpg",
    "image5.jpg"
    ];

let currentIndex = 0;
const sliderImage = document.getElementById("slider-image");
const imageNumber = document.getElementById("image-number");
const prevButton = document.getElementById("prev-button");
const nextButton = document.getElementById("next-button");

function updateSlider() {
    sliderImage.src = images[currentIndex];
    imageNumber.textContent = `Изображение ${currentIndex + 1} из ${images.length}`;
}

function showNextImage() {
    currentIndex = (currentIndex + 1) % images.length; // Зацикливание вперед
    updateSlider();
}

function showPrevImage() {
    currentIndex = (currentIndex - 1 + images.length) % images.length; // Зацикливание назад
    updateSlider();
}

nextButton.addEventListener("click", showNextImage);
prevButton.addEventListener("click", showPrevImage);

// Первоначальное обновление слайдера

updateSlider();