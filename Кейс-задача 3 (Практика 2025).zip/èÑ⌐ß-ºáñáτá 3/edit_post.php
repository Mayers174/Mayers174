<?php
session_start();
require_once 'config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <title>Редактирование постов</title>
   <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>Редактирование вашего поста</h2>
<a href='index.php'>На главную</a><br>
<?php
if (isset($_GET['id']) && isset($_SESSION['user_id'])) {
   $post_id = $_GET['id'];
   $user_id = $_SESSION['user_id'];

   if ($_SERVER['REQUEST_METHOD'] == 'POST') {
      $title = $_POST['title'];
      $content = $_POST['content'];
      $is_private = isset($_POST['is_private']) ? 1 : 0;
      $tags = $_POST['tags'] ?? '';

      $stmt = $pdo->prepare("UPDATE posts SET title = ?, content = ?, is_private = ?, tags = ? WHERE id = ? AND user_id = ?");
      $stmt->execute([$title, $content, $is_private, $tags, $post_id, $user_id]);
   }

   $stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ? AND user_id = ?");
   $stmt->execute([$post_id, $user_id]);
   $post = $stmt->fetch(PDO::FETCH_ASSOC);
   if (!$post) {
      echo "Пост не найден или закрыт доступ";
      exit;
   }
   ?>
   <div class="block">
   <form method="POST">
      <label for="title">Заголовок: </label>
      <input type="text" name="title" value="<?php echo htmlspecialchars($post['title']); ?>" required>
      <br><br><label for="">Содержание: </label>
      <textarea name="content" required><?php echo htmlspecialchars($post['content']); ?></textarea>
      <label for="tags">Тег: </label>
      <input type="text" name="tags" value="<?php echo htmlspecialchars($post['tags']); ?>">
      <label><input type="checkbox" name="is_private" <?php echo $post['is_private'] ? 'checked' : ''; ?>> Private</label>
      <button type="submit">Обновить</button>
   </form>
   </div>
   <?php
}