<?php
session_start();
require_once 'config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <title>Результаты запроса</title>
   <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>Результат по запросу</h2>
<a href='index.php'>На главную</a>
<?php
if (isset($_GET['tag'])) {
   $tag = $_GET['tag'];
   $stmt = $pdo->prepare("SELECT p.*, u.username FROM posts p JOIN users u ON p.user_id = u.id WHERE p.tags LIKE ? AND p.is_private = 0");
   $stmt->execute(["%$tag%"]);
   while($post = $stmt->fetch(PDO::FETCH_ASSOC)) {
      echo "<div class='post'>";
      echo "<h4>" . htmlspecialchars($post['title']) . "</h4>";
      echo "<p>" . htmlspecialchars($post['content']) . "</p>";
      echo "<small>By: " . htmlspecialchars($post['username']) . "</small>";
      echo "</div>";
   }
}