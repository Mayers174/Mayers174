<?php
session_start();
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
   $follower_id = $_SESSION['user_id'];
   $following_id = $_POST['user_id'];

   if(isset($_POST['followyes'])){
      $stmt = $pdo->prepare("INSERT INTO subscriptions (follower_id, following_id) VALUES (?, ?)");
      $stmt->execute([$follower_id, $following_id]);
      header("Location: index.php");
   } 
   if(isset($_POST['followno'])) {
      $stmt = $pdo->prepare("DELETE FROM subscriptions WHERE follower_id = ? AND following_id = ?");
      $stmt->execute([$follower_id, $following_id]);
      header("Location: index.php");
   }   
}