-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июл 01 2025 г., 07:01
-- Версия сервера: 8.0.19
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `blog`
--

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE `comments` (
  `id` int NOT NULL,
  `post_id` int NOT NULL,
  `user_id` int NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `user_id`, `content`, `created_at`) VALUES
(1, 2, 2, 'вау', '2025-06-27 04:45:02'),
(2, 9, 2, 'ghbdtn', '2025-06-27 09:12:38'),
(3, 9, 2, 'ghbdtn', '2025-06-27 09:14:06'),
(4, 9, 2, 'fgfgfg', '2025-06-27 09:14:55'),
(5, 9, 2, 'fgfgfg', '2025-06-27 09:17:49'),
(6, 7, 3, 'Привет!', '2025-06-30 10:44:08'),
(7, 7, 3, 'Привет!', '2025-06-30 10:47:03'),
(8, 7, 3, 'Здарова', '2025-06-30 10:50:17'),
(9, 7, 3, 'hi', '2025-06-30 10:58:15'),
(10, 7, 3, 'hi', '2025-06-30 10:58:49'),
(11, 7, 3, 'hi', '2025-06-30 11:00:26'),
(12, 1, 3, 'dfc', '2025-06-30 11:06:05'),
(13, 1, 3, 'dfc', '2025-06-30 11:07:49');

-- --------------------------------------------------------

--
-- Структура таблицы `posts`
--

CREATE TABLE `posts` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `is_private` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `tags` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `title`, `content`, `is_private`, `created_at`, `tags`) VALUES
(1, 1, 'Пост1', 'Lorem  consectetur adipisicing elit. Impedit amet qui hic, architecto culpa distinctio recusandae dolorem officia nihil sapiente suscipit reiciendis aut mollitia sint tenetur voluptatem placeat doloribus ea.', 0, '2025-06-27 04:17:27', 'lorem1'),
(2, 1, 'Пост 2', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit amet qui hic, architecto culpa distinctio recusandae dolorem officia nihil sapiente suscipit reiciendis aut mollitia sint tenetur voluptatem placeat doloribus ea.', 0, '2025-06-27 04:17:42', 'lorem2'),
(7, 2, 'Пост1', 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Aspernatur iusto dignissimos voluptatibus dolorum quasi ea , , in sint at , provident ducimus !', 0, '2025-06-27 08:00:25', 'we'),
(9, 2, 'Пост 3', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quo pariatur aperiam repudiandae. Recusandae dolor iusto minus modi maxime quaerat atque dignissimos, nostrum, ut ad veritatis laboriosam! Nisi soluta eligendi necessitatibus.', 0, '2025-06-27 08:33:28', 're'),
(11, 3, 'Пост1', 'Lorem dolor sit amet consectetur adipisicing elit. Impedit amet qui hic, architecto culpa distinctio recusandae dolorem officia nihil sapiente suscipit reiciendis aut mollitia sint tenetur voluptatem placeat doloribus ea.', 0, '2025-06-30 10:02:15', 'tag3');

-- --------------------------------------------------------

--
-- Структура таблицы `subscriptions`
--

CREATE TABLE `subscriptions` (
  `id` int NOT NULL,
  `follower_id` int NOT NULL,
  `following_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `subscriptions`
--

INSERT INTO `subscriptions` (`id`, `follower_id`, `following_id`) VALUES
(2, 2, 1),
(8, 1, 3),
(10, 3, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`) VALUES
(1, 'user1', '$2y$10$PD4u/YTEpnumI4GMbpkTdelvTRqw9aU95easTbPVk2vJu.9pjpHiG', 'user1@mail.ru'),
(2, 'user2', '$2y$10$91bWwNLUDwWAtxMJlVELeeA5NPLFSR.oW/se4vBusJxYFXyjTWt2m', 'user2@mail.ru'),
(3, 'user3', '$2y$10$N0p0MRCSI72ucCVa/Rv2X.0XXR7/9pwTovHSJtiXqt3culWMjeOSm', 'user3@mail.ru'),
(4, 'user4', '$2y$10$lZoy0WIQI6S/sl2y61HyOe4NnqrzwkLQe/JJfETpwKbSIUrWqDM6m', 'user4@mail.ru');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `follower_id` (`follower_id`),
  ADD KEY `following_id` (`following_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблицы `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `subscriptions`
--
ALTER TABLE `subscriptions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`),
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD CONSTRAINT `subscriptions_ibfk_1` FOREIGN KEY (`follower_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `subscriptions_ibfk_2` FOREIGN KEY (`following_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
