<?php
session_start();
require_once 'config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <title>Блоги по интересам</title>
   <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>Комментарии</h2>
<a href='index.php'>На главную</a>
<?php
if (isset($_GET['post_id']) && isset($_SESSION['user_id'])) {
   $post_id = $_GET['post_id'];
   $user_id = $_SESSION['user_id'];

   if ($_SERVER['REQUEST_METHOD'] == 'POST') {
      $content = $_POST['content'];
      $stmt = $pdo->prepare("INSERT INTO comments (post_id, user_id, content) VALUES (?, ?, ?)");
      $stmt->execute([$post_id, $user_id, $content]);
   }
   
   $stmt = $pdo->prepare("SELECT c.*, u.username FROM comments c JOIN users u ON c.user_id = u.id WHERE c.post_id = ?");
   $stmt->execute([$post_id]);
   while($comment = $stmt->fetch(PDO::FETCH_ASSOC)) {
      echo "<div class='comment'>";
      echo "<p>" . htmlspecialchars($comment['content']) . "</p>";
      echo "<small>Автор: " . htmlspecialchars($comment['username']) . "</small>";
      echo "</div>";
   }
   ?>
   
   <form method="POST" >
      <br><textarea name="content" placeholder="Напишите свой комментарий" required></textarea>
      <button type="submit">Отправить</button>
   </form>
   <?php
}