<?php
session_start();
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
   $title = $_POST['title'];
   $content = $_POST['content'];
   $tags = $_POST['tags'] ?? '';
   $is_private = isset($_POST['is_private']) ? 1 : 0;
   $user_id = $_SESSION['user_id'];

   $stmt = $pdo->prepare("INSERT INTO posts (user_id, title, content, is_private, tags) VALUES (?, ?, ?, ?, ?)");
   $stmt->execute([$user_id, $title, $content, $is_private, $tags]);
   header("Location: index.php");
}