<?php
   session_start();
   require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <title>Блоги по интересам</title>
   <link rel="stylesheet" href="style.css">
</head>
<body>
   <div class="container">
      <?php if(isset($_SESSION['user_id'])): ?>
            <h2>Добро пожаловать, <?php echo $_SESSION['username']; ?>!</h2>
            <a href="logout.php">Выйти</a>
            <div class="block">
            <h3>Создание поста</h3>
            <form action="create_post.php" method="POST">
               <div class="form-group">
                  <input type="text" name="title" placeholder="Заголовок" required>
               </div>
               <div class="form-group">
                  <textarea name="content" placeholder="Содержание" required></textarea>
               </div>
               <div class="form-group">
                  <input type="text" name="tags" placeholder="Теги">
               </div>
               <div class="form-group">
                  <label><input type="checkbox" name="is_private"> Закрытый пост</label>
               </div>
               <button type="submit">Создать</button>
            </form>
            </div>

            <div class="block">
            <p>Выберите автора для подписки: </p>
            <form action="subscribe.php" method="POST">
               <select name="user_id">
               <?php
               $stmt = $pdo->prepare("SELECT id, username FROM users WHERE id != ?");
               $stmt->execute([$_SESSION['user_id']]);
               while($user = $stmt->fetch(PDO::FETCH_ASSOC)) {
                  echo "<option value='" . $user['id'] . "'>" . htmlspecialchars($user['username']) . "</option>";
               } ?>
               </select>
               <button type="submit" name="followyes">Подписаться</button>
               <button type="submit" name="followno">Отписаться</button>      
               
            </form>
            </div>

            <div class="block">
            <h3>Мои подписки</h3>
            <?php
            $stmt = $pdo->prepare("SELECT p.*, u.username FROM posts p 
               JOIN users u ON p.user_id = u.id 
               JOIN subscriptions s ON p.user_id = s.following_id 
               WHERE s.follower_id = ? AND p.is_private = 0 
               ORDER BY p.created_at ASC");
            $stmt->execute([$_SESSION['user_id']]);
            while($post = $stmt->fetch(PDO::FETCH_ASSOC)) {
               echo "<div class='post'>";
               echo "<h4>" . htmlspecialchars($post['title']) . "</h4>";
               echo "<p>" . htmlspecialchars($post['content']) . "</p>";
               echo "<small>Автор: " . htmlspecialchars($post['username']) . "</small>";
               echo "<br><br><a href='comment.php?post_id=" . $post['id'] . "'>Комментарии</a>";
               echo "</div>";
            }
            ?>
            </div>

            <div class="block">
            <h3>Мои посты</h3>
            <?php
            $stmt = $pdo->prepare("SELECT p.*, u.username FROM posts p 
               JOIN users u ON p.user_id = u.id 
               WHERE p.user_id = ? 
               ORDER BY p.created_at ASC");
            $stmt->execute([$_SESSION['user_id']]);
            while($post = $stmt->fetch(PDO::FETCH_ASSOC)) {
               echo "<div class='post'>";
               echo "<h4>" . htmlspecialchars($post['title']) . "</h4>";
               echo "<p>" . htmlspecialchars($post['content']) . "</p>";
               echo " <a href='edit_post.php?id=" . $post['id'] . "'>Редактировать</a>";
               echo " <a href='delete_post.php?id=" . $post['id'] . "'>Удалить</a>";
               echo "</div>";
            }
            ?>
            </div>

            <div class="block">
               <h3>Показать посты по тегу:</h3>
               <form action="filter_tags.php" method="GET">
                  <input type="text" name="tag" placeholder="Введите тег">
                  <button type="submit">Показать</button>
               </form>
            </div>
            <div class="block">
            <h3>Публичные посты</h3>
            <?php
            $stmt = $pdo->prepare("SELECT p.*, u.username FROM posts p 
               JOIN users u ON p.user_id = u.id 
               WHERE p.is_private = 0 
               ORDER BY p.created_at ASC");
            $stmt->execute();
            while($post = $stmt->fetch(PDO::FETCH_ASSOC)) {
               echo "<div class='post'>";
               echo "<h4>" . htmlspecialchars($post['title']) . "</h4>";
               echo "<p>" . htmlspecialchars($post['content']) . "</p>";
               echo "<small>Автор: " . htmlspecialchars($post['username']) . "</small>";
               echo "<br><br><a href='comment.php?post_id=" . $post['id'] . "'>Комментарии</a>";
               echo "</div>";
            }
            ?>
            </div>

      <?php else: ?>
            <h2>Авторизация</h2>
            <form action="login.php" method="POST">
               <div class="form-group">
                  <input type="text" name="username" placeholder="Имя пользователя" required>
               </div>
               <div class="form-group">
                  <input type="password" name="password" placeholder="Пароль" required>
               </div>
               <button type="submit">Войти</button>
            </form>

            <h2>Регистрация</h2>
            <form action="register.php" method="POST">
               <div class="form-group">
                  <input type="text" name="username" placeholder="Имя пользователя" required>
               </div>
               <div class="form-group">
                  <input type="email" name="email" placeholder="Email" required>
               </div>
               <div class="form-group">
                  <input type="password" name="password" placeholder="Пароль" required>
               </div>
               <button type="submit">Зарегистрироваться</button>
            </form>
      <?php endif; ?>
   </div>
</body>
</html>