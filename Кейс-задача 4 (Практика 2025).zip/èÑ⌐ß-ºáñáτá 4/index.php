<?php
session_start();
require_once 'config.php';
?>

<!DOCTYPE html>
<html lang="ru">
<head>
   <meta charset="UTF-8">
   <title>Книжный магазин</title>
   <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
<h1>Книжный магазин</h1>
<?php if(isset($_SESSION['user_id'])){ ?>
   <a href="logout.php">Выйти</a>
<?php } ?>
</header>
<div class="container">
   <?php if(isset($_SESSION['user_id'])){
      $user_id = $_SESSION['user_id'];
      $stmt = $pdo->prepare("SELECT * FROM users WHERE id = $user_id");
      $stmt->execute();
      $user = $stmt->fetch(PDO::FETCH_ASSOC);

      if($user['role'] == 'admin'){
         require_once 'functions.php';
         // Получаем все книги
         $books = getBooks();
         ?>
         <h2>Администрирование книг</h2>
         <p><a href="books_edit.php">Добавить новую книгу</a></p>
         <table border="1" cellpadding="5" cellspacing="0">
            <thead>
            <tr>
               <th>ID</th>
               <th>Название</th>
               <th>Автор</th>
               <th>Категория</th>
               <th>Год</th>
               <th>Цена</th>
               <th>Статус</th>
               <th>Доступность</th>
               <th>Действия</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($books as $book): ?>
               <tr>
                  <td><?= $book['id'] ?></td>
                  <td><?= htmlspecialchars($book['title']) ?></td>
                  <td><?= htmlspecialchars($book['author']) ?></td>
                  <td><?= htmlspecialchars($book['category']) ?></td>
                  <td><?= $book['year'] ?></td>
                  <td><?= $book['price'] ?></td>
                  <td><?= $book['status'] ?></td>
                  <td><?= $book['availability'] ? 'Да' : 'Нет' ?></td>
                  <td><a href="books_edit.php?id=<?= $book['id'] ?>">Редактировать</a></td>
               </tr>
            <?php endforeach; ?>
            </tbody>
         </table>
         <?php
      }
      if($user['role'] == 'user'){
         require_once 'functions.php';
         $category = $_GET['category'] ?? null;
         $author = $_GET['author'] ?? null;
         $year = $_GET['year'] ?? null;
         $books = getBooks($category, $author, $year);
         ?>
         <h2>Библиотека книг</h2>
         <form method="get">
            <label>Категория: <input type="text" name="category" value="<?=htmlspecialchars($category)?>"></label><br>
            <label>Автор: <input type="text" name="author" value="<?=htmlspecialchars($author)?>"></label><br>
            <label>Год: <input type="number" name="year" value="<?=htmlspecialchars($year)?>"></label><br>
            <button type="submit">Фильтровать</button>
         </form><br>

         <table border="1" cellpadding="5" cellspacing="0">
            <thead>
            <tr>
               <th>Название</th>
               <th>Автор</th>
               <th>Категория</th>
               <th>Год</th>
               <th>Цена</th>
               <th>Доступность</th>
               <th>Действия</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($books as $book): ?>
               <tr>
                  <td><?=htmlspecialchars($book['title'])?></td>
                  <td><?=htmlspecialchars($book['author'])?></td>
                  <td><?=htmlspecialchars($book['category'])?></td>
                  <td><?=htmlspecialchars($book['year'])?></td>
                  <td><?=htmlspecialchars($book['price'])?> ₽</td>
                  <td><?=($book['availability']) ? 'Доступна' : 'Недоступна'?></td>
                  <td><a href="book_view.php?id=<?=$book['id']?>">Просмотр</a></td>
               </tr>
            <?php endforeach; ?>
            </tbody>
         </table>
         <?php
      }
   } else { ?>
      <h2>Авторизация</h2>
      <form action="login.php" method="POST">
         <div class="form-group">
            <input type="text" name="username" placeholder="Имя пользователя" required>
         </div>
         <div class="form-group">
            <input type="password" name="password" placeholder="Пароль" required>
         </div>
         <button type="submit">Войти</button>
      </form>

      <h2>Регистрация</h2>
      <form action="register.php" method="POST">
         <div class="form-group">
            <input type="text" name="username" placeholder="Имя пользователя" required>
         </div>
         <div class="form-group">
            <input type="email" name="email" placeholder="Email" required>
         </div>
         <div class="form-group">
            <input type="password" name="password" placeholder="Пароль" required>
         </div>
         <button type="submit">Зарегистрироваться</button>
      </form>
   <?php } ?>
   </div>
</body>
</html>