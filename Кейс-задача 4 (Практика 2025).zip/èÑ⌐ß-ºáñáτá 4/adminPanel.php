<?php
require_once 'functions.php';
// Получаем все книги
$books = getBooks();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
   <meta charset="UTF-8">
   <title>Админка - Книжный магазин</title>
   <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<h1>Администрирование книг</h1>
<a href="logout.php">Выйти</a>
<p><a href="books_edit.php">Добавить новую книгу</a></p>
<table border="1" cellpadding="5" cellspacing="0">
   <thead>
   <tr>
      <th>ID</th>
      <th>Название</th>
      <th>Автор</th>
      <th>Категория</th>
      <th>Год</th>
      <th>Цена</th>
      <th>Статус</th>
      <th>Доступность</th>
      <th>Действия</th>
   </tr>
   </thead>
   <tbody>
   <?php foreach ($books as $book): ?>
      <tr>
         <td><?= $book['id'] ?></td>
         <td><?= htmlspecialchars($book['title']) ?></td>
         <td><?= htmlspecialchars($book['author']) ?></td>
         <td><?= htmlspecialchars($book['category']) ?></td>
         <td><?= $book['year'] ?></td>
         <td><?= $book['price'] ?></td>
         <td><?= $book['status'] ?></td>
         <td><?= $book['availability'] ? 'Да' : 'Нет' ?></td>
         <td><a href="books_edit.php?id=<?= $book['id'] ?>">Редактировать</a></td>
      </tr>
   <?php endforeach; ?>
   </tbody>
</table>

</body>
</html>