<?php
require_once 'config.php';

// Получить книги с фильтрами
function getBooks($category = null, $author = null, $year = null) {
   global $pdo;
   $sql = "SELECT * FROM books WHERE 1=1";
   $params = [];

   if ($category) {
      $sql .= " AND category = ?";
      $params[] = $category;
   }
   if ($author) {
      $sql .= " AND author = ?";
      $params[] = $author;
   }
   if ($year) {
      $sql .= " AND year = ?";
      $params[] = $year;
   }

   $stmt = $pdo->prepare($sql);
   $stmt->execute($params);
   return $stmt->fetchAll();
}

// Получить книгу по ID
function getBookById($id) {
   global $pdo;
   $stmt = $pdo->prepare("SELECT * FROM books WHERE id = ?");
   $stmt->execute([$id]);
   return $stmt->fetch();
}

// Добавить или обновить книгу (админ)
function saveBook($data) {
   global $pdo;
   if (isset($data['id']) && $data['id']) {
      $stmt = $pdo->prepare("UPDATE books SET title=?, author=?, category=?, year=?, price=?, status=?, availability=? WHERE id=?");
      return $stmt->execute([
            $data['title'], $data['author'], $data['category'], $data['year'], $data['price'], $data['status'], $data['availability'], $data['id']
      ]);
   } else {
      $stmt = $pdo->prepare("INSERT INTO books (title, author, category, year, price, status, availability) VALUES (?, ?, ?, ?, ?, ?, ?)");
      return $stmt->execute([
            $data['title'], $data['author'], $data['category'], $data['year'], $data['price'], $data['status'], $data['availability']
      ]);
   }
}

// Аренда книги
function rentBook($userId, $bookId, $durationMonths) {
   global $pdo;
   $rentDate = date('Y-m-d');
   $returnDate = date('Y-m-d', strtotime("+$durationMonths months"));

    // Проверяем доступность книги
   $book = getBookById($bookId);
   if (!$book || !$book['availability'] || $book['status'] != 'available') {
      return false;
   }

    // Обновляем статус книги
   $stmt = $pdo->prepare("UPDATE books SET status='rented', availability=0 WHERE id=?");
   $stmt->execute([$bookId]);

    // Добавляем запись аренды
   $stmt = $pdo->prepare("INSERT INTO rentals (user_id, book_id, rent_date, return_date) VALUES (?, ?, ?, ?)");
   return $stmt->execute([$userId, $bookId, $rentDate, $returnDate]);
}

// Получить аренды с истекающим сроком (для напоминания)
function getExpiringRentals() {
   global $pdo;
   $today = date('Y-m-d');
   $soon = date('Y-m-d', strtotime('+3 days'));
   $stmt = $pdo->prepare("SELECT rentals.*, users.email, books.title 
                           FROM rentals 
                           JOIN users ON rentals.user_id = users.id 
                           JOIN books ON rentals.book_id = books.id 
                           WHERE rentals.status = 'active' AND rentals.return_date BETWEEN ? AND ?");
   $stmt->execute([$today, $soon]);
   return $stmt->fetchAll();
}
?>