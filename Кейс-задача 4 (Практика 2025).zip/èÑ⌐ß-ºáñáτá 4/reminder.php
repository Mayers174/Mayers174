<?php
require_once 'functions.php';

$rentals = getExpiringRentals();

foreach ($rentals as $rental) {
   $to = $rental['email'];
   $subject = "Напоминание о сроке аренды книги";
   $message = "Здравствуйте!\n\nСрок аренды книги \"{$rental['title']}\" заканчивается {$rental['return_date']}.\nПожалуйста, продлите аренду или верните книгу.\n\nСпасибо!";
   $headers = "From: bookstore@example.com";

   // mail($to, $subject, $message, $headers);
   echo "Отправлено письмо на $to: $subject\n";
}