<?php
require_once 'functions.php';

$id = $_GET['id'] ?? null;
$book = null;
if ($id) {
   $book = getBookById($id);
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   $data = [
      'id' => $_POST['id'] ?? null,
      'title' => $_POST['title'],
      'author' => $_POST['author'],
      'category' => $_POST['category'],
      'year' => (int)$_POST['year'],
      'price' => (float)$_POST['price'],
      'status' => $_POST['status'],
      'availability' => isset($_POST['availability']) ? 1 : 0,
   ];

   $success = saveBook($data);
   $message = $success ? 'Данные сохранены' : 'Ошибка при сохранении';
   if ($success && !$id) {
      header("Location: index.php");
      exit;
   }
}

?>

<!DOCTYPE html>
<html lang="ru">
<head>
   <meta charset="UTF-8">
   <title><?= $id ? 'Редактировать книгу' : 'Добавить книгу' ?></title>
   <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<h1><?= $id ? 'Редактировать книгу' : 'Добавить книгу' ?></h1>

<?php if ($message): ?>
   <p><strong><?= $message ?></strong></p>
<?php endif; ?>

<form method="post">
   <input type="hidden" name="id" value="<?= htmlspecialchars($book['id'] ?? '') ?>">
   <p>
      <label>Название: <input type="text" name="title" required value="<?= htmlspecialchars($book['title'] ?? '') ?>"></label>
   </p>
   <p>
      <label>Автор: <input type="text" name="author" required value="<?= htmlspecialchars($book['author'] ?? '') ?>"></label>
   </p>
   <p>
      <label>Категория: <input type="text" name="category" value="<?= htmlspecialchars($book['category'] ?? '') ?>"></label>
   </p>
   <p>
      <label>Год: <input type="number" name="year" value="<?= htmlspecialchars($book['year'] ?? '') ?>"></label>
   </p>
   <p>
      <label>Цена: <input type="number" step="0.01" name="price" value="<?= htmlspecialchars($book['price'] ?? '') ?>"></label>
   </p>
   <p>
      <label>Статус:
         <select name="status">
               <?php
               $statuses = ['available', 'rented', 'sold'];
               foreach ($statuses as $status):
                  $selected = ($book['status'] ?? '') === $status ? 'selected' : '';
                  ?>
                  <option value="<?= $status ?>" <?= $selected ?>><?= $status ?></option>
               <?php endforeach; ?>
         </select>
      </label>
   </p>
   <p>
      <label>Доступность: <input type="checkbox" name="availability" <?= (!isset($book['availability']) || $book['availability']) ? 'checked' : '' ?>></label>
   </p>
   <p>
      <button type="submit">Сохранить</button>
   </p>
</form>

<p><a href="index.php">Вернуться к списку</a></p>
</body>
</html>