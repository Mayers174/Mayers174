<?php
require_once '../functions.php';

$category = $_GET['category'] ?? null;
$author = $_GET['author'] ?? null;
$year = $_GET['year'] ?? null;

$books = getBooks($category, $author, $year);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
   <meta charset="UTF-8">
   <title>Книжный магазин - Пользователь</title>
   <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<h1>Библиотека книг</h1>
<a href="logout.php">Выйти</a>
<form method="get">
   <label>Категория: <input type="text" name="category" value="<?=htmlspecialchars($category)?>"></label>
   <label>Автор: <input type="text" name="author" value="<?=htmlspecialchars($author)?>"></label>
   <label>Год: <input type="number" name="year" value="<?=htmlspecialchars($year)?>"></label>
   <button type="submit">Фильтровать</button>
</form>

<table border="1" cellpadding="5" cellspacing="0">
   <thead>
   <tr>
      <th>Название</th>
      <th>Автор</th>
      <th>Категория</th>
      <th>Год</th>
      <th>Цена</th>
      <th>Доступность</th>
      <th>Действия</th>
   </tr>
   </thead>
   <tbody>
   <?php foreach ($books as $book): ?>
      <tr>
         <td><?=htmlspecialchars($book['title'])?></td>
         <td><?=htmlspecialchars($book['author'])?></td>
         <td><?=htmlspecialchars($book['category'])?></td>
         <td><?=htmlspecialchars($book['year'])?></td>
         <td><?=htmlspecialchars($book['price'])?> ₽</td>
         <td><?=($book['availability']) ? 'Доступна' : 'Недоступна'?></td>
         <td><a href="book_view.php?id=<?=$book['id']?>">Просмотр</a></td>
      </tr>
   <?php endforeach; ?>
   </tbody>
</table>

</body>
</html>