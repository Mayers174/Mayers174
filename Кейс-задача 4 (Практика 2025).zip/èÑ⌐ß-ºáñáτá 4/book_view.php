<?php
require_once 'functions.php';

$id = $_GET['id'] ?? null;
if (!$id) {
    die('Книга не найдена');
}

$book = getBookById($id);
if (!$book) {
    die('Книга не найдена');
}

// Эмуляция текущего пользователя (id=1)
$userId = 1;

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $duration = $_POST['duration'] ?? null;
    $durations = ['0.5' => '2 недели', '1' => '1 месяц', '3' => '3 месяца'];
    if (isset($durations[$duration])) {
        $success = rentBook($userId, $id, $duration);
        $message = $success ? "Книга успешно арендована на {$durations[$duration]}" : "Не удалось арендовать книгу";
    } else {
        $message = "Неверный срок аренды";
    }
}

?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Просмотр книги</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<h1><?=htmlspecialchars($book['title'])?></h1>
<p><strong>Автор:</strong> <?=htmlspecialchars($book['author'])?></p>
<p><strong>Категория:</strong> <?=htmlspecialchars($book['category'])?></p>
<p><strong>Год:</strong> <?=htmlspecialchars($book['year'])?></p>
<p><strong>Цена:</strong> <?=htmlspecialchars($book['price'])?> ₽</p>
<p><strong>Статус:</strong> <?=htmlspecialchars($book['status'])?></p>
<p><strong>Доступность:</strong> <?=($book['availability']) ? 'Доступна' : 'Недоступна'?></p>

<?php if ($book['availability'] && $book['status'] == 'available'): ?>
   <h3>Арендовать книгу</h3>
   <?php if ($message): ?>
      <p><strong><?=$message?></strong></p>
   <?php endif; ?>
   <form method="post">
      <select name="duration">
         <option value="0.5">2 недели</option>
         <option value="1">1 месяц</option>
         <option value="3">3 месяца</option>
      </select>
      <button type="submit">Арендовать</button>
   </form>
<?php else: ?>
   <p>Книга недоступна для аренды.</p>
<?php endif; ?>

<p><a href="index.php">Вернуться к списку</a></p>
</body>
</html>