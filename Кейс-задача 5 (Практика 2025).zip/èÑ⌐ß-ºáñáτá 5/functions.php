<?php
require_once 'config.php';

// Регистрация пользователя
function registerUser($username, $email, $password) {
   global $pdo;
   $hash = password_hash($password, PASSWORD_DEFAULT);
   $stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
   try {
      return $stmt->execute([$username, $email, $hash]);
   } catch (PDOException $e) {
      if ($e->getCode() == 23000) { // Дублирование уникального ключа
         return false;
      }
      throw $e;
   }
}

// Авторизация пользователя
function loginUser($username, $password) {
   global $pdo;
   $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
   $stmt->execute([$username]);
   $user = $stmt->fetch();
   if ($user && password_verify($password, $user['password'])) {
      $_SESSION['user_id'] = $user['id'];
      $_SESSION['username'] = $user['username'];
      return true;
   }
   return false;
}

// Проверка авторизации
function isLoggedIn() {
   return isset($_SESSION['user_id']);
}

// Получить путешествия всех пользователей
function getAllTrips() {
   global $pdo;
   $stmt = $pdo->query("SELECT trips.*, users.username FROM trips JOIN users ON trips.user_id = users.id ORDER BY trips.created_at DESC");
   return $stmt->fetchAll();
}

// Добавить путешествие
function addTrip($userId, $title, $description, $cost, $places, $imagePath) {
   global $pdo;
   $stmt = $pdo->prepare("INSERT INTO trips (user_id, title, description, cost, places, image_path) VALUES (?, ?, ?, ?, ?, ?)");
   return $stmt->execute([$userId, $title, $description, $cost, $places, $imagePath]);
}