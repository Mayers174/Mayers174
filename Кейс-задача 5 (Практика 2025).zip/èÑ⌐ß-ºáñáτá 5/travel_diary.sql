-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июл 02 2025 г., 09:11
-- Версия сервера: 8.0.19
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `travel_diary`
--

-- --------------------------------------------------------

--
-- Структура таблицы `trips`
--

CREATE TABLE `trips` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `cost` decimal(10,2) DEFAULT NULL,
  `places` text,
  `image_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `trips`
--

INSERT INTO `trips` (`id`, `user_id`, `title`, `description`, `cost`, `places`, `image_path`, `created_at`) VALUES
(1, 1, 'Спелео-тур в пещеру Киндерлинская', 'Пещера Киндерлинская им. 30-летия Победы (или просто Победа) это многоярусная система галерей, коридоров и ходов. В привходовой части находится самый протяженный в пещерах Башкирии ледник, площадью 720 м2 и мощностью до 8 м.\r\n\r\nПротяженность открытых ходов пещеры около 16 км. \r\n\r\nОдна из самых протяженных пещер Урала\r\nСказочные натеки\r\nСводы залов, высотой более 100 метров\r\nСказочно красивые ходы\r\nНас ждет увлекательное путешествие в подземную часть Уральских гор', '20000.00', 'водопады и горные ущелья, пещеры, древние рифы', 'uploads/6864cae2a390e.jpg', '2025-07-02 06:00:02'),
(2, 1, 'Покорить горные вершины Дагестана', 'Покорим множество горных вершин, откуда открываются виды захватывающие дух, а также посетим множество прекрасных природных чудес.\r\n\r\nмаксимум впечатлений\r\nмаксимум видов\r\nмаксимум эмоций\r\nв туре нас ждут самые красивые локации, вкусные национальные блюда, пешие прогулки.', '25000.00', 'горные вершины Дагестана', 'uploads/6864cb4736765.jpg', '2025-07-02 06:01:43'),
(3, 2, 'Спелеотур в Адыгее', 'Погрузитесь в загадочный подземный мир Лагонакского нагорья, где с каждым шагом открывается всё больше чудес природы. Этот тур откроет вам красоты карстовых образований и атмосферу спелеолога-первооткрывателя. Присоединяйтесь к нам, и вы почувствуете, что мир вокруг гораздо шире и интереснее, чем кажется на первый взгляд.\r\n\r\nПрирода Лаго-Наки это величественные горы и завораживающий подземный мир. Узнаем об одной из самых глубоких пещер России и восхитимся тысячами сталактитов и сталагмитов, откроем для себя тайны, которые познали только сотни исследователей. Не упустите шанс увидеть это чудо своими глазами!', '62900.00', 'Природа Лаго-Наки', 'uploads/6864cc1e3301d.jpg', '2025-07-02 06:05:18');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `created_at`) VALUES
(1, 'user1', 'user1@mail.ru', '$2y$10$1epN8DJ8/sK7JhVfb0I7ceuNlj2oA4NzuU0nI2SUrhHbVqkrftOnS', '2025-07-02 05:46:44'),
(2, 'user2', 'user2@mail.ru', '$2y$10$KJuHJQ06IPIiRiOMA4f.Ce4K.ek3kEwq4Wf1fXz/yiPk60nHY.Sa.', '2025-07-02 06:01:59');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `trips`
--
ALTER TABLE `trips`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `trips`
--
ALTER TABLE `trips`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `trips`
--
ALTER TABLE `trips`
  ADD CONSTRAINT `trips_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
