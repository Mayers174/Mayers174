<?php
require_once 'functions.php';

if (!isLoggedIn()) {
   header('Location: ../auth/login.php');
   exit;
}

$trips = getAllTrips();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
   <meta charset="UTF-8">
   <title>Путешествия</title>
   <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<h2>Путешествия пользователей</h2>
<p><a href="../user/add_trip.php">Добавить путешествие</a> | <a href="../auth/logout.php">Выход</a></p>

<?php if (!$trips): ?>
   <p>Путешествий пока нет.</p>
<?php else: ?>
   <?php foreach ($trips as $trip): ?>
      <div style="border:1px solid #ccc; padding:10px; margin-bottom:10px; background:#fff;">
         <h3><?=htmlspecialchars($trip['title'])?></h3>
         <p><strong>Автор:</strong> <?=htmlspecialchars($trip['username'])?></p>
         <p><strong>Описание:</strong> <?=nl2br(htmlspecialchars($trip['description']))?></p>
         <p><strong>Стоимость:</strong> <?=htmlspecialchars($trip['cost'])?> ₽</p>
         <p><strong>Места для посещения:</strong> <?=htmlspecialchars($trip['places'])?></p>
         <?php if ($trip['image_path']): ?>
               <p><img src="../<?=$trip['image_path']?>" alt="Изображение путешествия" style="max-width:300px;"></p>
         <?php endif; ?>
         <p><em>Добавлено: <?=htmlspecialchars($trip['created_at'])?></em></p>
      </div>
   <?php endforeach; ?>
<?php endif; ?>

</body>
</html>