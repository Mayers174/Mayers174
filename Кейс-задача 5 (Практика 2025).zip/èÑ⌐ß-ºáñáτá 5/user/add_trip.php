<?php
require_once '../functions.php';

if (!isLoggedIn()) {
   header('Location: ../auth/login.php');
   exit;
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   $title = trim($_POST['title']);
   $description = trim($_POST['description']);
   $cost = floatval($_POST['cost']);
   $places = trim($_POST['places']);
   $imagePath = '';

   // Загрузка изображения
   if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
      $fileTmpPath = $_FILES['image']['tmp_name'];
      $fileName = basename($_FILES['image']['name']);
      $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
      $allowed = ['jpg', 'jpeg', 'png', 'gif'];
      if (in_array($ext, $allowed)) {
         $newFileName = uniqid() . '.' . $ext;
         $destPath = '../uploads/' . $newFileName;
         if (move_uploaded_file($fileTmpPath, $destPath)) {
               $imagePath = 'uploads/' . $newFileName;
         } else {
               $message = 'Ошибка загрузки изображения.';
         }
      } else {
         $message = 'Недопустимый формат изображения.';
      }
   }

   if (!$message) {
      if (addTrip($_SESSION['user_id'], $title, $description, $cost, $places, $imagePath)) {
         $message = 'Путешествие успешно добавлено.';
      } else {
         $message = 'Ошибка при добавлении путешествия.';
      }
   }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
   <meta charset="UTF-8">
   <title>Добавить путешествие</title>
   <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<h2>Добавить путешествие</h2>
<p><a href="../index.php">Просмотр всех путешествий</a> | <a href="../auth/logout.php">Выход</a></p>

<?php if ($message): ?>
   <p><strong><?=$message?></strong></p>
<?php endif; ?>

<form method="post" enctype="multipart/form-data">
   <p><input type="text" name="title" placeholder="Название путешествия" required></p>
   <p><textarea name="description" placeholder="Описание" rows="5"></textarea></p>
   <p><input type="number" step="0.01" name="cost" placeholder="Стоимость" required></p>
   <p><input type="text" name="places" placeholder="Места для посещения (через запятую)" required></p>
   <p>Изображение: <input type="file" name="image" accept="image/*"></p>
   <p><button type="submit">Добавить</button></p>
</form>
</body>
</html>