<?php
require_once '../functions.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   $username = trim($_POST['username']);
   $password = $_POST['password'];

   if (loginUser($username, $password)) {
      header('Location: ../index.php');
      exit;
   } else {
      $message = 'Неверный логин или пароль.';
   }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
   <meta charset="UTF-8">
   <title>Вход</title>
   <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<h2>Вход</h2>
<?php if ($message): ?>
   <p style="color:red;"><?=$message?></p>
<?php endif; ?>
<form method="post">
   <p><input type="text" name="username" placeholder="Логин" required></p>
   <p><input type="password" name="password" placeholder="Пароль" required></p>
   <p><button type="submit">Войти</button></p>
</form>
<p><a href="register.php">Регистрация</a></p>
</body>
</html>