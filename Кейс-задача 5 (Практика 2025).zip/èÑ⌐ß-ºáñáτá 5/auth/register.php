<?php
require_once '../functions.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   $username = trim($_POST['username']);
   $email = trim($_POST['email']);
   $password = $_POST['password'];
   $password_confirm = $_POST['password_confirm'];

   if ($password !== $password_confirm) {
      $message = 'Пароли не совпадают.';
   } elseif (registerUser($username, $email, $password)) {
      header('Location: login.php');
      exit;
   } else {
      $message = 'Ошибка регистрации: возможно, логин или email уже заняты.';
   }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
   <meta charset="UTF-8">
   <title>Регистрация</title>
   <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<h2>Регистрация</h2>
<?php if ($message): ?>
   <p style="color:red;"><?=$message?></p>
<?php endif; ?>
<form method="post">
   <p><input type="text" name="username" placeholder="Логин" required></p>
   <p><input type="email" name="email" placeholder="Email" required></p>
   <p><input type="password" name="password" placeholder="Пароль" required></p>
   <p><input type="password" name="password_confirm" placeholder="Повторите пароль" required></p>
   <p><button type="submit">Зарегистрироваться</button></p>
</form>
<p><a href="login.php">Войти</a></p>
</body>
</html>